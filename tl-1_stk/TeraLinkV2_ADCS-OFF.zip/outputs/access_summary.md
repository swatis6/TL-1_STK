Access summary over 336 days

| Station | Type | Passes | Passes/day | Avg pass (s) | Max pass (s) | Total contact (h) |
|---|---|---|---|---|---|---|
| AWSBahrain | Visible (>= 30 deg) | 432 | 1.29 | 125.8 | 180.3 | 15.1 |
| AWSBahrain | In SBand antenna cone | 432 | 1.29 | 125.8 | 180.3 | 15.1 |
| AWSCapeTown | Visible (>= 30 deg) | 528 | 1.57 | 126.7 | 183.4 | 18.6 |
| AWSCapeTown | In SBand antenna cone | 528 | 1.57 | 126.7 | 183.4 | 18.6 |
| AWSIreland | Visible (>= 30 deg) | 806 | 2.4 | 126.1 | 174.7 | 28.2 |
| AWSIreland | In SBand antenna cone | 806 | 2.4 | 126.1 | 174.7 | 28.2 |
| NUTHzGS | Visible (>= 70 deg) | 146 | 0.43 | 27.4 | 40.8 | 1.1 |
| NUTHzGS | In THz antenna cone | 146 | 0.43 | 27.4 | 40.8 | 1.1 |
| NUuhfGS | Visible (>= 10 deg) | 1871 | 5.57 | 287.5 | 401.1 | 149.4 |
| NUuhfGS | In UHF antenna cone | 1871 | 5.57 | 287.5 | 401.1 | 149.4 |
